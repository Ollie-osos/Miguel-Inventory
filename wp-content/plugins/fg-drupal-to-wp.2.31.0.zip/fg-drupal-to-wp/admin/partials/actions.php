				<tr>
					<th scope="row">&nbsp;</th>
					<td><?php submit_button( __('Save settings', 'fg-drupal-to-wp'), 'secondary', 'save' ); ?>
					<?php submit_button( __('Start / Resume the import', 'fg-drupal-to-wp'), 'primary', 'import' ); ?>
					<span id="action_message" class="action_message"></span>
					<?php submit_button( __('Stop import', 'fg-drupal-to-wp'), 'secondary', 'stop-import' ); ?>
					</td>
				</tr>
