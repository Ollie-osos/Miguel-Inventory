		<div id="fgd2wp_database_info">
			<h3><?php _e('WordPress database', 'fg-drupal-to-wp') ?></h3>
			<div id="fgd2wp_database_info_content">
				<?php print $data['database_info']; ?>
			</div>
		</div>
